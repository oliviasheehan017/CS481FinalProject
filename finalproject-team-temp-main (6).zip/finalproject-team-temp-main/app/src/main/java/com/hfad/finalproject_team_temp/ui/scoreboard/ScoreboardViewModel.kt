package com.hfad.finalproject_team_temp.ui.scoreboard

import androidx.lifecycle.ViewModel

class ScoreboardViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}