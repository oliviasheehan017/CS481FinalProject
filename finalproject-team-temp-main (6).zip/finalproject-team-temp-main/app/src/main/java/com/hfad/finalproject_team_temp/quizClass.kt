package com.hfad.finalproject_team_temp

data class quizClass(val Title: CharSequence, val questions: ArrayList<String>, val answers: ArrayList<String>)
